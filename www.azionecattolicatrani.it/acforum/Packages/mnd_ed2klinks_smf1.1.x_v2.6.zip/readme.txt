This mod adds support for ed2k (plain and AICH). It assumes you want to process the links, even if you have html disabled.

It supports both <a href> and standalone links and places an emule icon placed before them. There is no configuration to be done, just paste the links and you're done.

Thanks to Simmiyy for a bug correction on the latest version and the icon feature.