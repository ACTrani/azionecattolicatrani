<edit file>
$boarddir/index.php
</edit file>

<search for>
* =============================================================================== *
* Software Version:           SMF 1.1.17                                          *
</search for>

<replace>
* =============================================================================== *
* Software Version:           SMF 1.1.18                                          *
</replace>

<search for>
$forum_version = 'SMF 1.1.17';
</search for>

<replace>
$forum_version = 'SMF 1.1.18';
</replace>


<edit file>
$sourcedir/Register.php
</edit file>

<search for>
* =============================================================================== *
* Software Version:           SMF 1.1.10                                          *
</search for>

<replace>
* =============================================================================== *
* Software Version:           SMF 1.1.18                                          *
</replace>

<search for>
	if (isset($_POST['new_email'], $_REQUEST['passwd']) && sha1(strtolower($row['memberName']) . $_REQUEST['passwd']) == $row['passwd'])
</search for>

<replace>
	if (isset($_POST['new_email'], $_REQUEST['passwd']) && sha1(strtolower($row['memberName']) . $_REQUEST['passwd']) == $row['passwd'] && ($row['is_activated'] == 0 || $row['is_activated'] == 2))
</replace>


<edit file>
$sourcedir/Themes.php
</edit file>

<search for>
* =============================================================================== *
* Software Version:           SMF 1.1.11                                          *
</search for>

<replace>
* =============================================================================== *
* Software Version:           SMF 1.1.18                                          *
</replace>

<search for>
	list ($theme_dir, $context['theme_id']) = mysql_fetch_row($request);
	mysql_free_result($request);
</search for>

<replace>
	list ($theme_dir, $context['theme_id']) = mysql_fetch_row($request);
	mysql_free_result($request);

	if (!file_exists($theme_dir . '/index.template.php'))
		fatal_lang_error('theme_edit_missing', false);
</replace>


<edit file>
$sourcedir/Reminder.php
</edit file>

<search for>
* =============================================================================== *
* Software Version:           SMF 1.1.6                                           *
</search for>

<replace>
* =============================================================================== *
* Software Version:           SMF 1.1.18                                          *
</replace>

<search for>
	if (empty($_POST['code']) || substr($realCode, 0, 10) != substr(md5($_POST['code']), 0, 10))
</search for>

<replace>
	if (empty($_POST['code']) || substr($realCode, 0, 10) !== substr(md5($_POST['code']), 0, 10))
</replace>
