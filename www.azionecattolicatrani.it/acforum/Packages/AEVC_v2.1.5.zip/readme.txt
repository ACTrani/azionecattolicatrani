[center][hr][color=red][size=16pt][b]AUTO EMBED VIDEO CLIPS v2.1.5[/b][/size][/color]
[url=http://custom.simplemachines.org/mods/index.php?action=profile;u=63186][b]By Karl Benson[/b][/url]
[hr][url=http://custom.simplemachines.org/mods/index.php?mod=977][b]Link to Mod[/b][/url] | [url=http://www.simplemachines.org/community/index.php?topic=200401.0][b]Support Topic[/b][/url] | [url=http://www.adrevenueshare.com/index.php?topic=16.0][b]Demo[/b][/url] | [url=http://www.adrevenueshare.com/donate][b]Donate[/b][/url][hr][/center]

[color=blue][size=12pt][u][b]Compatibility[/b][/u][/size][/color]
For SMF 1.1.x and SMF 2.0 Beta x

[color=blue][size=12pt][u][b]Introduction[/b][/u][/size][/color]
Automatically embeds video clips from links for 50+ sites including YouTube/DailyMotion/MetaCafe/GoogleVideo without the need for html or bbcode.

Just copy the url from your address bar into a post and let the mod will do the rest.
Its the ultimate user friendly way of posting clips and safe from a security standpoint.

[color=blue][size=12pt][u][b]Features[/b][/u][/size][/color]
o Supports [b]50+[/b] Video clip sites
- 123video.nl, Aniboom, AOL Uncut, AtomFilms, AtomFilms Uploads, Biku, BrightCove, CellFish, ClipFish.de, CollegeHumor, DailyMotion.com, DailyMotion.Alice.It, Dave.tv, dv.ouou, ESPN, Gametrailers, Gametube.org GameVideos, Glumbert, Godtube, GoFish, Google Video, Guba, IFilm, Imageshack.us, Jeux-france.com, Jubii.co.uk, Koreus, Libero.it, LiveLeak, LiveVideo, Megavideo, MetaCafe, MSN Live/Soapbox Video, Mofile, MThai, MySpaceTv, MyVideo.de, OnSmash, Photobucket, Revver, Sevenload, Sina.com.cn, Streetfire.net, Stupidvideos.com, Tudou, UUME.com, Veoh, videotube.de, Vidiac, VidMax, Vimeo, VSocial, WeGame, Yahoo, Yahoo HK, Youku, YouTube (including Playlists)
o Safe from security standpoint
- They can't just embed ANY object hosted ANYWHERE, it only works for trusted supported sites
- Properly validates/sanitizes/parses the video id before including it in the url
- Disables script access (allowScriptAccess="never")
o No configuration necessary
o Works for all themes/languages, no manual edits necessary
o Use [noembed][/noembed] bbcode to prevent links being converted to embedded clips
o Hard-coded limit to number to converted links per page (to prevent flash overload/browser crash)
- Only applies to links converted by this mod (not other video clip mods)
o Disabled for Printer Friendly pages & Signatures
o Since all the videos are hosted by external sites, it won't consume your bandwidth

Since the mod only converts active links, it is recommended to have the setting "Automatically link posted URLs" enabled. 
(via Admin > Posts & Topics > Bulletin Board Code)
Other than that there are no admin settings with this mod. Uninstall the mod to disable it.

Other video mods (such as my [url=http://custom.simplemachines.org/mods/index.php?mod=936]YouTube BBCode mod[/url]) will take precedence for bbcoded links.

Note: Some users have reported that the players won't go fullscreen. This maybe caused by bugs in some versions of Adobe Flash Player when wmode="transparent" is in use. Check [url=http://kb.adobe.com/selfservice/viewContent.do?externalId=tn_15507][here][/url] whether you have the latest version of Adobe Flash Player.

Note: Are some YouTube clips not working? YouTube has recently started allowing clip authors to prevent users external embedding their clips.  So if a YouTube clip doesn't work, check at youtube for the embed code. Where it says "Embedding disabled by request", those clips will only work when viewed at YouTube.

[color=blue][size=12pt][u][b]Installation[/b][/u][/size][/color]
Any previous versions of this mod MUST be uninstalled BEFORE installing this version.

Install the mod via the SMF Package Manager, and your done. It installs on [b]ALL[/b] themes automatically as it only affects Source files.
There are NO theme edits required and there are NO language strings to translate.

[b]Useful Links[/b]
[url=http://www.adrevenueshare.com/parser]SMF Package Parser[/url]
[url=http://docs.simplemachines.org/index.php?topic=402]Manual Installation Of Mods[/url]
[url=http://www.simplemachines.org/community/index.php?topic=24110.0]How Do I Modify Files?[/url]

[color=blue][size=12pt][u][b]Donate[/b][/u][/size][/color]
Has this modification helped you? Support the developer by [url=http://www.adrevenueshare.com/donate][color=red][b]Donating[/b][/color][/url]

[color=blue][size=12pt][u][b](Optional) Convert Old Video BBCode[/b][/u][/size][/color]
(Mysql users only) If you have had video bbcode mods previously installed eg [nobbc][youtube][/nobbc], then you might want to use my [url=http://custom.simplemachines.org/mods/index.php?mod=977]convert_old_video_bbcodes.php[/url] script to convert bbcoded video links to normal links (and therefore make those links work with this mod).

Use this at your OWN risk.
This cannot be undone, so backup your database and files prior to running it.
Upload it via ftp to your directory where SMF runs from. Put your forum in maintenance mode, and then point to it in your browser.
For security reasons, remove the file once completed.
o Only applies to topics/posts.
o Works for valid links or ids
o Works for both types of bbcode (with or without sizes)
o Converts the following bbcodes
[nobbc][youtube], [yt], [ytplaylist], [stage6], [metacafe], [googlevid], [gv], [google_video], [gvideo], [dailymotion], [livevideo], [liveleak], [myvideo], [clipfish], [veoh][/nobbc]
Other uses of the bbcode will remain untouched.
o You can use the script at any time (with or without the AutoEmbedVideoClips mod installed)

[color=blue][size=12pt][u][b]Customizing[/b][/u][/size][/color]
The mod has been designed to be fully functional 'out of the box' and not require any configuration or manual edits.
However some 'hardcoded' capability/hooks have been included for those who understand php/smf and maybe wish to customize the mod.

[b]Enable/Disable Specific Sites[/b]
Eg to enable/disable YouTube

Open Sources/Subs-AutoEmbedVideoClips.php
FIND
[code]		array(
			'name' => 'YouTube',
			'enabled' => 1,[/code]
Change the number 1 to enable, 0 to disable (note, all sites are enabled by default)
Similarly change it for any of the other sites supported to disable them.

[b]Increase/Decrease The Limit On The Number Embedded Objects Per Page[/b]
Too much flash can be bad for your health (eg it will crash your browser).  Thats why the limit was put in place.
IE, Firefox, Opera etc start kicking and screaming if you get over 10 objects.
Open Sources/Subs.php
FIND
[CODE]	static $autoembedmax = 12 ;[/CODE]
Change 12 to another number. Use -1 for no limit (Not Recommended).

[b]Disabling Embedding In Specific Areas[/b]
By default embedding is disabled in signatures.
Some people requested a way to disable it for other sections such as Shoutbox.
You must find in the relevant SOURCE file where that string or data is put through the function "parse_bbc"
And on the line BEFORE it, put
[code]$context['disableautoembedvideo'] = 1 ;[/code]

[color=blue][size=12pt][u][b]Support[/b][/u][/size][/color]
Please use the modification thread for support with this modification.
(Please don't ask me to do the edits for you)

Note: I do NOT have the time nor the desire to provide support for making or helping to make this mod support videos hosted on your OWN site.
You may be able to find someone to help by posting a request in the [url=http://www.simplemachines.org/community/index.php?board=50.0]Help Wanted[/url] board on the SimpleMachines.org
But be careful with regex patterns.

Note: Whilst I do take requests to support other popular video clip sites in future versions, it is [b]NOT[/b] possible to add support for the following sites because the video id/filename in the url is not the same as in the actual filename in the embed code.
Break.com, ebaumsworld, garagetv.be, 56.com, Blip.Tv, slideshare.net, videojug, vidlife, Filefront, IGN, Hulu, Gamespot, Dipvid, youSportz, tinypic.com, BBC Iplayer, BBC, crunchyroll.com, itv.com, 4od, JibJab, PlayFrance.com.
I won't include sites which require users 'fishing' in the embed code for the correct file url.

No adult/porn ones please (although most will NOT work anyway).

[color=blue][size=12pt][u][b]Changelog[/b][/u][/size][/color]
I am still recommending anyone who is using less than v2.1 to uninstall that version and then install the latest version.
[b]2.1.5 - 19th March 2008[/b]
o Removed Hulu (Since the address bar links don't work)
o Added Support for
- Jeux-france.com
- Jubii.co.uk
- Gametube.org
- UUME.com
o Added function_exists checks (to prevent error on uninstall)
o Ensured works for SMF 2.0 Beta 3. (its does!)
For the full changelog for previous versions please see changelog.txt